import sys

from pyspark.sql import SparkSession


class SparkHelper(object):
    @staticmethod
    def get_spark_session(app_name='spark_app', spark_config={}):
        """
        :param app_name: Name of the application
        :param spark_config: Spark configuration
        :return: Spark session
        """
        # get Spark session factory
        #When running through pycharm
        # jar_path = "/Users/nsrinivas/work/my_learning/xml_parsing/lib/com.databricks_spark-xml_2.10-0.4.1.jar"
        # spark_builder = SparkSession.builder.appName("Spark - XML read").master("local[*]") \
        #     .config("spark.jars", jar_path) \
        #     .config("spark.executor.extraClassPath", jar_path) \
        #     .config("spark.executor.extraLibrary", jar_path) \
        #     .config("spark.driver.extraClassPath", jar_path) \
        #     .config("spark.driver.bindAddress", "localhost") \

        # While running with spark-submit
        spark_builder = SparkSession \
            .builder \
            .appName(app_name)

        return spark_builder.getOrCreate()

    @staticmethod
    def read_xml(spark, file_path, xml_schema):
        """
        :param spark: spark_session
        :param file_path: path of file to read
        :param xml_schema: xml schema
        :return: Dataframe
        """
        print('Reading XML file, Path:{0}'.format(file_path))

        try:
            df = spark.read.format("xml") \
                .option("rowTag", "T-837") \
                .option("valueTag", False) \
                .load(file_path, schema=xml_schema)
        except Exception as e:
            print('Error while reading file. At path:{0} . Error:{1}'.format(file_path, e))
            sys.exit(16)
        return df

    @staticmethod
    def read_data(spark, file_path):
        """
        :param spark: spark_session
        :param file_path: path of file to read parquet file
        :return: returns spark Dataframe
        """
        print('Reading Parquet Path:{1}'.format(file_path))

        try:
            df = spark.read.parquet(file_path)
        except Exception as e:
            print('Error while reading at path:{0}, Error:{1}'.format(file_path, str(e)))
            sys.exit(16)
        return df

    @staticmethod
    def write_data(data_frame, file_path):
        """
        :param data_frame: data frame to write
        :param file_path: save output location
        :return: None
        """
        print('Writing data to Path:{0}'.format(data_frame))

        try:
            data_frame.write.parquet(file_path)
        except Exception as e:
            print('Error while writing at path:{0}, Error:{1}'.format(file_path, str(e)))
            sys.exit(16)
