from pyspark.sql.types import *


class Xml_Utilities(object):

    @staticmethod
    def xml_schema():
        xml_schema = StructType()
        xml_schema.add("ActivityID", StringType(), True)
        xml_schema.add("ECN", StringType(), True)

        s_hl = StructType()
        for ehl in range(1, 5):
            s_hl.add("E_HL0{0}".format(ehl), IntegerType(), True)

        s_sbr = StructType()
        for esbr in range(1, 10):
            s_sbr.add("E_SBR0{0}".format(esbr), StringType(), True)

        l2010ba = StructType([
            StructField("S_DMG",
                        StructType([
                            StructField("E_DMG01", StringType(), True),
                            StructField("E_DMG02", StringType(), True),
                            StructField("E_DMG03", StringType(), True)]), True),
            StructField("S_N3",
                        StructType([StructField("E_N301", StringType(), True)]), True),
            StructField("S_N4",
                        StructType([
                            StructField("E_N401", StringType(), True),
                            StructField("E_N402", StringType(), True),
                            StructField("E_N403", StringType(), True)]), True),
            StructField("S_NM1",
                        StructType([
                            StructField("E_NM101", StringType(), True),
                            StructField("E_NM102", StringType(), True),
                            StructField("E_NM103", StringType(), True),
                            StructField("E_NM104", StringType(), True),
                            StructField("E_NM105", StringType(), True),
                            StructField("E_NM106", StringType(), True),
                            StructField("E_NM107", StringType(), True),
                            StructField("E_NM108", StringType(), True),
                            StructField("E_NM109", StringType(), True)]), True),
        ])

        l_2010bb = StructType([
            StructField("S_N3",
                        StructType([StructField("E_N301", StringType(), True)]), True),
            StructField("S_N4",
                        StructType([
                            StructField("E_N401", StringType(), True),
                            StructField("E_N402", StringType(), True),
                            StructField("E_N403", StringType(), True)]), True),
            StructField("S_NM1",
                        StructType([
                            StructField("E_NM101", StringType(), True),
                            StructField("E_NM102", StringType(), True),
                            StructField("E_NM103", StringType(), True),
                            StructField("E_NM104", StringType(), True),
                            StructField("E_NM105", StringType(), True),
                            StructField("E_NM106", StringType(), True),
                            StructField("E_NM107", StringType(), True),
                            StructField("E_NM108", StringType(), True),
                            StructField("E_NM109", StringType(), True)]), True),
        ])

        l_2400 = StructField("L_2400",
                             ArrayType(StructType([
                                 StructField("Line_DCN_Nbr", StringType(), True),
                                 StructField("S_DTP",
                                             StructType([
                                                 StructField("E_DTP01", StringType(), True),
                                                 StructField("E_DTP02", StringType(), True),
                                                 StructField("E_DTP03", StringType(), True)]), True),

                                 StructField("S_LX", StructType([StructField("E_LX01", IntegerType(), True)]), True),
                                 StructField("S_REF_3",
                                             StructType([
                                                 StructField("E_REF01", StringType(), True),
                                                 StructField("E_REF02", StringType(), True)]), True),
                                 StructField("S_SV1",
                                             StructType([StructField("C_SV101",
                                                                     StructType([
                                                                         StructField("E_C00301", StringType(), True),
                                                                         StructField("E_C00302", StringType(), True),
                                                                         StructField("E_C00303", StringType(), True),
                                                                     ]), True),
                                                         StructField("C_SV107",
                                                                     StructType([
                                                                         StructField("E_C00401", IntegerType(), True)
                                                                     ]), True),
                                                         StructField("E_SV102", StringType(), True),
                                                         StructField("E_SV103", StringType(), True),
                                                         StructField("E_SV104", StringType(), True),
                                                         StructField("E_SV105", StringType(), True),
                                                         StructField("E_SV106", StringType(), True),
                                                         ]), True),
                                 StructField("L_2420G",
                                             ArrayType(
                                                 StructType([
                                                     StructField("S_N3",
                                                                 StructType([StructField("E_N301", StringType())])),
                                                     StructField("S_N4",
                                                                 StructType([
                                                                     StructField("E_N401", StringType()),
                                                                     StructField("E_N402", StringType()),
                                                                     StructField("E_N403", StringType())]))
                                                 ]))),

                             ]), True))
        # L_2300
        l_2300 = StructType([
            StructField("L_2310A",
                        StructType([
                            StructField("S_NM1",
                                        StructType([
                                            StructField("E_NM101", StringType(), True),
                                            StructField("E_NM102", StringType(), True),
                                            StructField("E_NM103", StringType(), True),
                                            StructField("E_NM104", StringType(), True),
                                            StructField("E_NM105", StringType(), True),
                                            StructField("E_NM106", StringType(), True),
                                            StructField("E_NM107", StringType(), True),
                                            StructField("E_NM108", StringType(), True),
                                            StructField("E_NM109", StringType(), True)]), True)
                        ]), True),
            StructField("L_2310B",
                        StructType([
                            StructField("S_NM1",
                                        StructType([
                                            StructField("E_NM101", StringType(), True),
                                            StructField("E_NM102", StringType(), True),
                                            StructField("E_NM103", StringType(), True),
                                            StructField("E_NM104", StringType(), True),
                                            StructField("E_NM105", StringType(), True),
                                            StructField("E_NM106", StringType(), True),
                                            StructField("E_NM107", StringType(), True),
                                            StructField("E_NM108", StringType(), True),
                                            StructField("E_NM109", StringType(), True)]), True),
                            StructField("S_PRV",
                                        StructType([
                                            StructField("E_PRV01", StringType(), True),
                                            StructField("E_PRV02", StringType(), True),
                                            StructField("E_PRV03", StringType(), True)]), True),
                        ]), True),
            StructField("L_2310C",
                        StructType([
                            StructField("S_N3",
                                        StructType([StructField("E_N301", StringType(), True)]), True),
                            StructField("S_N4",
                                        StructType([
                                            StructField("E_N401", StringType(), True),
                                            StructField("E_N402", StringType(), True),
                                            StructField("E_N403", StringType(), True)]), True),
                            StructField("S_NM1",
                                        StructType([
                                            StructField("E_NM101", StringType(), True),
                                            StructField("E_NM102", StringType(), True),
                                            StructField("E_NM103", StringType(), True)]), True),
                        ]), True), l_2400,
            StructField("S_CLM",
                        StructType([
                            StructField("C_CLM05",
                                        StructType([
                                            StructField("E_C02301", StringType(), True),
                                            StructField("E_C02302", StringType(), True),
                                            StructField("E_C02303", StringType(), True)
                                        ]), True),
                            StructField("E_CLM01", StringType(), True),
                            StructField("E_CLM02", StringType(), True),
                            StructField("E_CLM03", StringType(), True),
                            StructField("E_CLM04", StringType(), True),
                            StructField("E_CLM06", StringType(), True),
                            StructField("E_CLM07", StringType(), True),
                            StructField("E_CLM08", StringType(), True),
                            StructField("E_CLM09", StringType(), True),
                            StructField("E_CLM10", StringType(), True)]), True),
            StructField("S_HI",
                        StructType([
                            StructField("C_HI01",
                                        StructType([
                                            StructField("E_C02201", StringType(), True),
                                            StructField("E_C02202", StringType(), True)]), True)
                        ]), True),
            StructField("S_REF_10",
                        StructType([
                            StructField("E_REF01", StringType(), True),
                            StructField("E_REF02", StringType(), True)
                        ]), True),
            StructField("S_REF_6",
                        StructType([
                            StructField("E_REF01", StringType(), True),
                            StructField("E_REF02", StringType(), True)
                        ]), True),
        ])

        xml_schema.add("L_2000B",
                       StructType([
                           StructField("L_2010BA", l2010ba, True),
                           StructField("L_2010BB", l_2010bb, True),
                           StructField("L_2300", l_2300, True),
                           StructField("S_HL", s_hl, True),
                           StructField("S_SBR", s_sbr, True)
                       ])
                       , True)
        xml_schema.add("_CreatedBy", StringType(), True)
        xml_schema.add("_CreatedDate", StringType(), True)
        xml_schema.add("_GUID", StringType(), True)
        xml_schema.add("_Standard", StringType(), True)
        xml_schema.add("_Version", StringType(), True)
        xml_schema.add("_XDataVersion", DoubleType(), True)
        xml_schema.add("_xmlns", StringType(), True)
        xml_schema.add("_xsi", StringType(), True)
