import pyspark.sql.functions as F
import os

from src.common.spark_helper import SparkHelper
from src.common.utils import Xml_Utilities

class First_Read(object):

    @staticmethod
    def save():
        spark = SparkHelper.get_spark_session()
        xml_schema = Xml_Utilities.xml_schema()
        path = os.getcwd()
        print(path)
        df = SparkHelper.read_xml(spark=spark,
                                  file_path="/Users/nsrinivas/work/my_learning/xml_parsing/consul/xml_files/",
                                  xml_schema=xml_schema)

        SparkHelper.write_data(df, "first_output")

        # df = df.select(F.explode(F.col("L_2000B.L_2300.L_2400")).alias("l2400"), F.col("ECN"))
        #
        # df = df.withColumn("DCN", F.col("l2400.Line_DCN_Nbr")) \
        #     .withColumn("l2420g", F.explode_outer("l2400.L_2420G"))
        #
        # df = df.select("ECN", "DCN", "l2420g.*")
        # # df.show(truncate=False)
        #
        # df = df.selectExpr("S_N3.E_N301 as E_2420G_NM1_1_01_1",
        #                    "S_N4.E_N401 as E_2420G_NM4_1_01_1",
        #                    "S_N4.E_N402 as E_2420G_NM4_1_01_2",
        #                    "S_N4.E_N403 as E_2420G_NM4_1_01_3")
        #
        # df.show(truncate=False)
        #
        # df = df.withColumn("CASECOL", F.when(F.col('E_2420G_NM4_1_01_1') == '1-ASHEVILLE', F.col("E_2420G_NM1_1_01_1")))
        #
        # df.show(truncate=False)
