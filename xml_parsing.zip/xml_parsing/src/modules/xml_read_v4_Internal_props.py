import pyspark.sql.functions as F
from pyspark.sql import SparkSession
from pyspark.sql.types import *

# https://mvnrepository.com/artifact/com.databricks/spark-xml_2.12/0.6.0
# https://mvnrepository.com/artifact/com.databricks/spark-xml_2.11/0.6.0
# https://www.programcreek.com/python/example/104711/pyspark.sql.types.ArrayType

# path="/user/ex63/t837.xml"
# sc.newAPIHadoopFile(path, "org.apache.hadoop.mapreduce.lib.input.TextInputFormat",
#                     "org.apache.hadoop.io.LongWritable", "org.apache.hadoop.io.Text",
#                     conf={"textinputformat.record.delimiter": '</delimiter>'})\
#     .map(lambda num_line: num_line[1]).take(2)

jar_path = "/Users/nsrinivas/work/my_learning/unittesting/com.databricks_spark-xml_2.10-0.4.1.jar"

spark = SparkSession.builder.appName("Spark - XML read").master("local[*]") \
    .config("spark.jars", jar_path) \
    .config("spark.executor.extraClassPath", jar_path) \
    .config("spark.executor.extraLibrary", jar_path) \
    .config("spark.driver.extraClassPath", jar_path) \
    .config("spark.driver.bindAddress", "localhost") \
    .config("spark.debug.maxToStringFields", 200) \
    .getOrCreate()

ds3 = StructType([StructField("Lookup",
                              ArrayType(
                                  StructType(
                                      [StructField("_Name", StringType()),
                                       StructField("false", LongType())])
                              )),
                  StructField("Property",
                              ArrayType(
                                  StructType(
                                      [StructField("_Name", StringType()),
                                       StructField("false", StringType())])
                              )),
                  StructField("_Name", StringType())
                  ])
ds = StructType([
    StructField("Data-Structure",
                StructType([
                    StructField("Data-Structure",
                                StructType([
                                    StructField("Data-Structure", ds3),
                                    StructField("Lookup",
                                                ArrayType(
                                                    StructType(
                                                        [StructField("_Name", StringType()),
                                                         StructField("false", StringType())])
                                                    )),
                                    StructField("Property",
                                                ArrayType(
                                                    StructType(
                                                        [StructField("_Name", StringType()),
                                                         StructField("false", StringType())])
                                                    )),
                                    StructField("_Name", StringType()),
                                ])),
                    StructField("Lookup",
                                ArrayType(
                                    StructType(
                                        [StructField("_Name", StringType()),
                                         StructField("false", StringType())])
                                    )),
                    StructField("Property",
                                ArrayType(
                                    StructType(
                                        [StructField("_Name", StringType()),
                                         StructField("false", StringType())])
                                    )),
                    StructField("_Name", StringType())
                ]))])

xml_schema = StructType()
xml_schema.add("ActivityID", StringType())
xml_schema.add("ECN", DoubleType())

xml_schema.add("Internal-Properties", ds)
xml_schema.add("_CreatedBy", "string")
xml_schema.add("_CreatedDate", "string")
xml_schema.add("_GUID", "string")
xml_schema.add("_Standard", "string")
xml_schema.add("_Version", "string")
xml_schema.add("_XDataVersion", "double")
xml_schema.add("_xmlns", "string")
xml_schema.add("_xsi", "string")

df = spark.read.format("xml").option("rowTag", "T-837").option("valueTag", "false") \
    .load("consul/837p_XML_internalprops.xml"
          , schema=xml_schema
          )
df.show()

# df = df.select(
#     F.col('Internal-Properties.Data-Structure._Name').alias('ds1name'),
#     F.col('Internal-Properties.Data-Structure.Lookup').alias('ds1lookup'),
#     F.col('Internal-Properties.Data-Structure.Property').alias('ds1prop'),
#     F.col('Internal-Properties.Data-Structure.Data-Structure._Name').alias('ds2name'),
#     F.col('Internal-Properties.Data-Structure.Data-Structure.Lookup').alias('ds2lookup'),
#     F.col('Internal-Properties.Data-Structure.Data-Structure.Property').alias('ds2prop'),
#     F.col('Internal-Properties.Data-Structure.Data-Structure.Data-Structure._Name').alias('ds3name'),
#     F.col('Internal-Properties.Data-Structure.Data-Structure.Data-Structure.Lookup').alias('ds3lookup'),
#     F.col('Internal-Properties.Data-Structure.Data-Structure.Data-Structure.Property').alias('ds3prop'),
#     "_CreatedBy","_XDataVersion"
# )
#
# df = df.withColumn("IC_STANDARD_LKUP", F.col("ds1lookup")[0]['false']) \
#     .withColumn("IC_USAGE_ID_LKUP", F.col("ds1lookup")[1]['false']) \
#     .withColumn("IC_SENDER_QUAL_LKUP", F.col("ds1lookup")[2]['false']) \
#     .withColumn("IC_SENDER_ID_LKUP", F.col("ds1lookup")[3]['false']) \
#     .withColumn("IC_RECEIVER_QUAL_LKUP", F.col("ds1lookup")[4]['false']) \
#     .withColumn("IC_RECEIVER_ID_LKUP", F.col("ds1lookup")[5]['false']) \
#     .withColumn("IC_CTRL_VERSION_LKUP", F.col("ds1lookup")[6]['false'])
#
# df.show()
