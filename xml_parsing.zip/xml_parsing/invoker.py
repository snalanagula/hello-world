import argparse
import logging
import sys

from src.common.spark_helper import SparkHelper
from src.modules.xml_parse import First_Read

parser = argparse.ArgumentParser(description="837 XML Parsing")
parser.add_argument('-input', type=str, help='input read location', required=True)
parser.add_argument('-op_path', type=str, help='destination parquet path', required=True)
parser.add_argument('-module_name', type=str, help='module name to be called', required=True)

if __name__ == '__main__':
    spark = SparkHelper.get_spark_session("XML Parse")
    args = parser.parse_args()

    if args.input is None or args.op_path is None or args.module_name is None:
        parser.print_help()
        sys.exit(1)

    input_path = args.input
    recipes_save_path = args.op_path
    mdl = args.module_name
    mdl = mdl.upper()

    if mdl == "FIRST_LOAD":
        print("Running XML Read and save parquet")
        First_Read.save()
    elif mdl == "NEXT_TABLE":
        print("Running Future Data Cube")
        # call second method
    else:
        print("Invalid Argument passed. No Module to Run for Argument:{0}".format(mdl))
        sys.exit(1)