#/usr/bin/bash

# Create a zip file
zip -r xml_parse.zip src/ lib/ test/

moduel_to_run=$1


spark-submit --master 'local[2]' \
   --jars lib/com.databricks_spark-xml_2.10-0.4.1.jar \
   --py-files xml_parse.zip invoker.py -input ippath -op_path oppath -module_name FIRST_LOAD

#spark-submit \
#  --master yarn \
#  --deploy-mode client
#  --py-files xml_parse.zip \
#  --jars lib/com.databricks_spark-xml_2.10-0.4.1.jar \
#  invoker.py -input ippath -op_path oppath -module_name FIRST_LOAD

if [ $? -ne 0 ]; then
  echo "Spark submit for module filed"
  exit 1
fi